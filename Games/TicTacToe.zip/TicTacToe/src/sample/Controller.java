package sample;

import javafx.beans.Observable;
import javafx.collections.ObservableArray;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;

import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.atomic.LongAccumulator;

public class Controller {

    @FXML GridPane gameView;
    @FXML Label score1,score2,player1Label,player2Label;

    String color = "#d49506";
    boolean player1Turn = true;
    int player1Score = 0;
    int player2Score = 0;

    char[][] gameBoard = new char[3][3];

    // when the user clicks on one of the empty spaces of the game board this code will
    // 1) Get the symbol (X or O depending on the player's turn)
    // 2) get the row and column as indexes to use them for the 2D array
    // 3) call the Play function
    // 4) call the printBoard function
    // 5) call the gameOver function
    // 6) play a chalk writing sound effect
    public void onMouseClick(MouseEvent mouseEvent) {
        char symbol = player1Turn ? 'X' : 'O';
        Label label = (Label) mouseEvent.getSource();
        int pos = gameView.getChildren().lastIndexOf(label);
        int row = pos / 3;
        int column = pos % 3;
        Play(symbol,row,column);
    }

    // this function will reset the gameBoard 2D array and call the printBoard function
    // and play an erasing chalk sound effect
    public void clearBoard(){
        gameBoard = new char[3][3];
        printBoard();
        Media media = new Media(new File("erase.wav").toURI().toString());
        MediaPlayer player = new MediaPlayer(media);
        player.play();
    }

    // this function will reset the players' scores and call the clearBoard function
    public void restartGame(ActionEvent actionEvent) {
        player1Turn = true;
        player2Label.setStyle("-fx-border-color: black;");
        player1Label.setStyle("-fx-border-color: " + color);
        player1Score = 0;
        player2Score = 0;
        score1.setText("0");
        score2.setText("0");
        clearBoard();
    }

    // this function will check if the place the player chose is empty or not
    // and if it's indeed empty it will play normally and then it would be the other player's turn
    // and the player would know that because we are changing the border colors around the players' labels
    // but if it's not empty then it will show an alert to the user that it's not empty
    // and they should choose another spot
    public void Play(char symbol, int row, int column){
        if(gameBoard[row][column]==0){
            gameBoard[row][column] = symbol;
            Media media = new Media(new File("soundEffect.wav").toURI().toString());
            MediaPlayer player = new MediaPlayer(media);
            player.play();
            printBoard();
            gameOver();
            player1Turn = !player1Turn;
            if(player1Turn){
                player2Label.setStyle("-fx-border-color: black;");
                player1Label.setStyle("-fx-border-color: " + color);
            }
            else{
                player1Label.setStyle("-fx-border-color: black;");
                player2Label.setStyle("-fx-border-color: " + color);
            }
        }
        else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("The position you have chosen is already filled please pick another spot");
            alert.setHeaderText("");
            alert.show();
        }
    }

    // this function just prints the gameBoard to the gameView
    public void printBoard(){
        ObservableList<Node> list = gameView.getChildren();
        for(int i = 0; i < list.size()-1;i++){
            int row = i / 3;
            int column = i % 3;
            ((Label)list.get(i)).setText(gameBoard[row][column] + "");
        }
    }

    // this function checks if the game is over and if a player wins then they get an increase in their score
    // and an alert will be shown to let them know who won that round
    // and if its a tie then an alert will be shown to tell them that it's a tie
    // and if the game is indeed over then this function will call the clear board function
    public void gameOver(){
        boolean end;
        if(gameBoard[0][0] == gameBoard [0][1] && gameBoard[0][0] == gameBoard [0][2] && gameBoard[0][0] != 0){ // 1st row check
            end = true;
        }
        else if(gameBoard[1][0] == gameBoard [1][1] && gameBoard[1][0] == gameBoard [1][2] && gameBoard[1][0] != 0){ // 2nd row check
            end = true;
        }
        else if(gameBoard[2][0] == gameBoard [2][1] && gameBoard[2][0] == gameBoard [2][2] && gameBoard[2][0] != 0){ // 3rd row check
            end = true;
        }
        else if(gameBoard[0][0] == gameBoard [1][0] && gameBoard [0][0] == gameBoard[2][0] && gameBoard[0][0] != 0){ // 1st column check
            end = true;
        }
        else if(gameBoard[0][1] == gameBoard [1][1] && gameBoard [0][1] == gameBoard[2][1] && gameBoard[0][1] != 0){ // 2nd column check
            end = true;
        }
        else if(gameBoard[0][2] == gameBoard [1][2] && gameBoard [0][2] == gameBoard[2][2] && gameBoard[0][2] != 0){ // 3rd column check
            end = true;
        }
        else if(gameBoard[0][0] == gameBoard[1][1] && gameBoard[0][0] == gameBoard[2][2] && gameBoard[0][0] != 0){ // left cross
            end = true;
        }
        else if(gameBoard[0][2] == gameBoard[1][1] && gameBoard[0][2] == gameBoard[2][0] && gameBoard[0][2] != 0){ // right cross
            end = true;
        }
        else{
            end = false;
        }

        if(end){
            if(player1Turn) {
                player1Score++;
                score1.setText(player1Score + "");
            }
            else {
                player2Score++;
                score2.setText(player2Score + "");
            }
            String player = player1Turn ? "Player 1" : "Player 2";
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText("");
            alert.setContentText(player + " WON!!!");
            alert.show();
            clearBoard();
        }
        int counter = 0;
        for(char[] row : gameBoard){
            for(char column : row){
                if(column != 0) counter ++;
            }
        }
        if(counter == 9){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText("");
            alert.setContentText("IT'S A TIE");
            alert.show();
            clearBoard();
        }
    }
}
